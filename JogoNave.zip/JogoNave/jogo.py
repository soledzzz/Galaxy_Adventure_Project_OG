import pygame
import random
import sqlite3

pygame.init()

LARGURA = 1920
ALTURA = 1080
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Jogo da Nave")

PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
VERMELHO = (255, 0, 0)
AZUL = (0, 0, 255)
VERDE = (0, 255, 0)
CINZA = (128, 128, 128)
AMARELO = (255, 255, 0)
BORDO = (139, 0, 0)
CINZA_ESCURO = (50, 50, 50)
AZUL_ESCURO = (0, 0, 139)
CINZA_CLARO = (200, 200, 200)

# Aumentar o tamanho da nave e dos asteroides
nave_padrao = pygame.image.load("nave2.png").convert_alpha()
nave_padrao = pygame.transform.scale(nave_padrao, (200, 200))  # Aumentar o tamanho da nave
background = pygame.image.load("background.png").convert()
background = pygame.transform.scale(background, (LARGURA, ALTURA))
fundo_loja = pygame.image.load("fundo_loja.png").convert()
fundo_loja = pygame.transform.scale(fundo_loja, (LARGURA, ALTURA))
background_jogo = pygame.image.load("background_jogo.png").convert()
background_jogo = pygame.transform.scale(background_jogo, (LARGURA, ALTURA))
asteroide_img = pygame.image.load("asteroide.png").convert_alpha()
asteroide_img = pygame.transform.scale(asteroide_img, (100, 100))  # Aumentar o tamanho dos asteroides
moeda_img = pygame.image.load("moeda.png").convert_alpha()
moeda_img = pygame.transform.scale(moeda_img, (130, 130))  # Aumentar o tamanho da imagem da moeda
inventario_img = pygame.image.load("inventario_mochila.png").convert_alpha()
inventario_img = pygame.transform.scale(inventario_img, (150, 150))  # Ajustar o tamanho da imagem do inventário

velocidade = 5
velocidade_tiro = 5
clock = pygame.time.Clock()

fonte = pygame.font.Font("PressStart2P.ttf", 24)
fonte_moedas = pygame.font.Font("PressStart2P.ttf", 48)  # Aumentar o tamanho da fonte para as moedas
fonte_game_over = pygame.font.Font("PressStart2P.ttf", 72)
fonte_padrao = pygame.font.Font("PressStart2P.ttf", 24)
fonte_loja_titulo = pygame.font.Font("OwlyBarn.ttf", 72)  # Fonte Owly Barn para o título da loja

naves_loja = [pygame.image.load(f"nave{i}.png").convert_alpha() for i in range(2, 12)]
naves_loja = [pygame.transform.scale(nave, (200, 200)) for nave in naves_loja]  # Aumentar o tamanho das naves na loja
nomes_naves = ["Falcão Espacial", "Estrela Veloz", "Cometa de Fogo", "Vento Cósmico", "Relâmpago Galáctico", "Nebulosa Negra", "Astro Guerreiro", "Meteorito de Prata", "Vórtice Estelar", "Fantasma do Espaço"]
precos_naves = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]

def criar_banco_de_dados():
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS jogador (id INTEGER PRIMARY KEY, moedas INTEGER, nave_selecionada INTEGER)''')
    cursor.execute("""INSERT OR IGNORE INTO jogador (id, moedas, nave_selecionada) VALUES (1, 0, 0)""")
    cursor.execute('''CREATE TABLE IF NOT EXISTS naves_compradas (id INTEGER PRIMARY KEY)''')
    conn.commit()
    conn.close()

def carregar_dados():
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('SELECT moedas, nave_selecionada FROM jogador WHERE id = 1')
    dados = cursor.fetchone()
    conn.close()
    return dados[0] if dados else 0, dados[1] if dados else 0

def salvar_dados(moedas, nave_selecionada):
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE jogador SET moedas = ?, nave_selecionada = ? WHERE id = 1', (moedas, nave_selecionada))
    conn.commit()
    conn.close()

def desenha_texto(tela, texto, fonte, cor, x, y):
    superficie = fonte.render(texto, True, cor)
    tela.blit(superficie, (x, y))

def salvar_nave_comprada(nave_id):
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('INSERT OR IGNORE INTO naves_compradas (id) VALUES (?)', (nave_id,))
    conn.commit()
    conn.close()

def nave_comprada(nave_id):
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM naves_compradas WHERE id = ?', (nave_id,))
    comprada = cursor.fetchone() is not None
    conn.close()
    return comprada

def carregar_naves_compradas():
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM naves_compradas')
    naves = cursor.fetchall()
    conn.close()
    return [nave[0] for nave in naves]

def salvar_nave_selecionada(nave_id):
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE jogador SET nave_selecionada = ? WHERE id = 1', (nave_id,))
    conn.commit()
    conn.close()

def carregar_nave_selecionada():
    conn = sqlite3.connect('jogo_nave.db')
    cursor = conn.cursor()
    cursor.execute('SELECT nave_selecionada FROM jogador WHERE id = 1')
    nave_selecionada = cursor.fetchone()[0]
    conn.close()
    return nave_selecionada

def tela_inicial(moedas):
    input_box = pygame.Rect(LARGURA // 2 - 150, ALTURA // 2 - 100, 300, 50)
    button_box = pygame.Rect(LARGURA // 2 - 150, ALTURA // 2 - 30, 300, 50)
    loja_box = pygame.Rect(LARGURA // 2 - 150, ALTURA // 2 + 50, 300, 50)
    sair_box = pygame.Rect(LARGURA // 2 - 150, ALTURA // 2 + 130, 300, 50)
    inventario_box = pygame.Rect(10, ALTURA - 160, 150, 150)
    font = pygame.font.Font("PressStart2P.ttf", 24)
    nome = ''
    iniciar_jogo = False
    abrir_loja = False
    abrir_inventario = False
    cor_botao = CINZA_ESCURO
    cor_botao_clicado = CINZA_CLARO
    cor_texto = BRANCO
    cor_sombra = (0, 0, 0, 128)
    cor_reflexo = (255, 255, 255, 128)
    piscando = True
    contador_piscando = 0
    cursor_visivel = True
    cursor_contador = 0

    while not iniciar_jogo and not abrir_loja and not abrir_inventario:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_RETURN:
                    iniciar_jogo = True
                elif evento.key == pygame.K_BACKSPACE:
                    nome = nome[:-1]
                else:
                    nome += evento.unicode
            if evento.type == pygame.MOUSEBUTTONDOWN:
                if button_box.collidepoint(evento.pos):
                    iniciar_jogo = True
                if loja_box.collidepoint(evento.pos):
                    abrir_loja = True
                if inventario_box.collidepoint(evento.pos):
                    abrir_inventario = True
                if sair_box.collidepoint(evento.pos):
                    pygame.quit()
                    exit()

        tela.blit(background, (0, 0))

        mouse_pos = pygame.mouse.get_pos()
        if button_box.collidepoint(mouse_pos):
            button_color = cor_botao_clicado
        else:
            button_color = cor_botao

        if loja_box.collidepoint(mouse_pos):
            loja_color = cor_botao_clicado
        else:
            loja_color = cor_botao

        if sair_box.collidepoint(mouse_pos):
            sair_color = cor_botao_clicado
        else:
            sair_color = cor_botao

        pygame.draw.rect(tela, button_color, button_box, border_radius=10)
        pygame.draw.rect(tela, loja_color, loja_box, border_radius=10)
        pygame.draw.rect(tela, sair_color, sair_box, border_radius=10)

        desenha_texto(tela, "INICIAR JOGO", font, cor_texto, button_box.centerx - font.size("INICIAR JOGO")[0] // 2, button_box.centery - font.size("INICIAR JOGO")[1] // 2)
        desenha_texto(tela, "LOJA", font, cor_texto, loja_box.centerx - font.size("LOJA")[0] // 2, loja_box.centery - font.size("LOJA")[1] // 2)
        desenha_texto(tela, "SAIR", font, cor_texto, sair_box.centerx - font.size("SAIR")[0] // 2, sair_box.centery - font.size("SAIR")[1] // 2)
        tela.blit(moeda_img, (10, 10))
        desenha_texto(tela, f'{moedas}', fonte_moedas, cor_texto, 150, 50)  # Ajustar a posição do texto das moedas

        # Animação do ícone do inventário
        if inventario_box.collidepoint(mouse_pos):
            tela.blit(inventario_img, (15, ALTURA - 165))
        else:
            tela.blit(inventario_img, (10, ALTURA - 160))

        pygame.draw.rect(tela, cor_texto, button_box, 2, border_radius=10)
        pygame.draw.rect(tela, cor_texto, loja_box, 2, border_radius=10)
        pygame.draw.rect(tela, cor_texto, sair_box, 2, border_radius=10)
        pygame.draw.rect(tela, cor_texto, input_box, 2, border_radius=10)

        # Reflexo de luz
        pygame.draw.line(tela, cor_reflexo, (button_box.x, button_box.y), (button_box.x + button_box.width, button_box.y), 2)
        pygame.draw.line(tela, cor_reflexo, (loja_box.x, loja_box.y), (loja_box.x + loja_box.width, loja_box.y), 2)
        pygame.draw.line(tela, cor_reflexo, (sair_box.x, sair_box.y), (sair_box.x + sair_box.width, sair_box.y), 2)
        pygame.draw.line(tela, cor_reflexo, (input_box.x, input_box.y), (input_box.x + input_box.width, input_box.y), 2)

        # Sombra projetada
        pygame.draw.line(tela, cor_sombra, (button_box.x, button_box.y + button_box.height), (button_box.x + button_box.width, button_box.y + button_box.height), 2)
        pygame.draw.line(tela, cor_sombra, (loja_box.x, loja_box.y + loja_box.height), (loja_box.x + loja_box.width, loja_box.y + loja_box.height), 2)
        pygame.draw.line(tela, cor_sombra, (sair_box.x, sair_box.y + sair_box.height), (sair_box.x + sair_box.width, sair_box.y + sair_box.height), 2)
        pygame.draw.line(tela, cor_sombra, (input_box.x, input_box.y + input_box.height), (input_box.x + input_box.width, input_box.y + input_box.height), 2)

        text_surface = font.render(nome, True, cor_texto)
        tela.blit(text_surface, (input_box.x + 5, input_box.y + 5))
        if cursor_visivel:
            cursor_surface = font.render('|', True, cor_texto)
            tela.blit(cursor_surface, (input_box.x + 5 + text_surface.get_width(), input_box.y + 5))
        cursor_contador += 1
        if cursor_contador % 30 == 0:
            cursor_visivel = not cursor_visivel

        if nome == '':
            nickname_surface = font.render("nickname", True, cor_texto)
            nickname_rect = nickname_surface.get_rect(center=(input_box.x + input_box.w // 2, input_box.y + input_box.h // 2))
            tela.blit(nickname_surface, nickname_rect)
        input_box.w = max(200, text_surface.get_width() + 10)

        # Texto piscando
        if contador_piscando % 60 < 30:
            desenha_texto(tela, "Press Start", font, cor_texto, LARGURA // 2 - font.size("Press Start")[0] // 2, ALTURA // 2 + 250)
        contador_piscando += 1

        pygame.display.flip()
        clock.tick(30)

    return nome, abrir_loja, abrir_inventario

def tela_loja(moedas):
    loja_rodando = True
    voltar_box = pygame.Rect(LARGURA // 2 - 50, ALTURA - 100, 100, 40)
    margem = 60  # Aumentar a margem para separar melhor as naves

    while loja_rodando:
        tela.blit(fundo_loja, (0, 0))
        tela.blit(moeda_img, (10, 10))
        desenha_texto(tela, f'{moedas}', fonte_moedas, BRANCO, 150, 50)  # Ajustar a posição do texto das moedas

        # Cabeçalhos estilizados
        titulo_rect = pygame.Rect(LARGURA // 2 - 350, 10, 700, 100)
        pygame.draw.rect(tela, CINZA_ESCURO, titulo_rect)
        pygame.draw.rect(tela, AZUL_ESCURO, titulo_rect, 5)
        titulo_surface = fonte_loja_titulo.render("Loja de Naves Espaciais", True, BRANCO)
        titulo_rect_surface = titulo_surface.get_rect(center=titulo_rect.center)
        tela.blit(titulo_surface, titulo_rect_surface)

        # Parte 2: Criação do grid das naves, com imagens e descrições
        for i in range(10):
            x = (i % 5) * (200 + margem) + (LARGURA // 2 - (5 * (200 + margem)) // 2)
            y = (i // 5) * (200 + margem) + 150
            nave_rect = pygame.Rect(x - 5, y - 5, 210, 260)
            pygame.draw.rect(tela, BRANCO, nave_rect)
            pygame.draw.rect(tela, CINZA_ESCURO, nave_rect, 2)
            desenha_texto(tela, nomes_naves[i], fonte, AZUL_ESCURO, nave_rect.centerx - fonte.size(nomes_naves[i])[0] // 2, y - 30)
            tela.blit(naves_loja[i], (x, y))

            # Parte 3: Adição dos botões de "Comprar" e suas funcionalidades
            comprar_box = pygame.Rect(x, y + 210, 200, 30)
            pygame.draw.rect(tela, AZUL_ESCURO, comprar_box)
            desenha_texto(tela, f'Comprar - {precos_naves[i]}', fonte, BRANCO, comprar_box.centerx - fonte.size(f'Comprar - {precos_naves[i]}')[0] // 2, comprar_box.y + 5)

            if comprar_box.collidepoint(pygame.mouse.get_pos()):
                if pygame.mouse.get_pressed()[0]:
                    if moedas >= precos_naves[i]:
                        moedas -= precos_naves[i]
                        salvar_nave_comprada(i)
                        desenha_texto(tela, "Comprado!", fonte, VERDE, comprar_box.centerx - fonte.size("Comprado!")[0] // 2, comprar_box.y + 5)
                    else:
                        desenha_texto(tela, "Moedas insuficientes!", fonte, VERMELHO, comprar_box.centerx - fonte.size("Moedas insuficientes!")[0] // 2, comprar_box.y + 5)

        pygame.draw.rect(tela, VERMELHO, voltar_box)
        desenha_texto(tela, "VOLTAR", fonte_padrao, BRANCO, voltar_box.centerx - fonte_padrao.size("VOLTAR")[0] // 2, voltar_box.y + 10)
        pygame.draw.rect(tela, BRANCO, voltar_box, 2)

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.MOUSEBUTTONDOWN:
                if voltar_box.collidepoint(evento.pos):
                    loja_rodando = False

        pygame.display.flip()
        clock.tick(30)

    return moedas

def tela_inventario(moedas):
    inventario_rodando = True
    voltar_box = pygame.Rect(LARGURA // 2 - 50, ALTURA - 100, 100, 40)
    margem_horizontal = 100  # Aumentar a margem horizontal para separar melhor as naves
    margem_vertical = 100  # Aumentar a margem vertical para separar melhor as naves
    naves_compradas = carregar_naves_compradas()
    nave_selecionada = carregar_nave_selecionada()

    # Ajustar o tamanho das naves para caber na tela
    nave_largura = 150
    nave_altura = 150
    naves_loja_redimensionadas = [pygame.transform.scale(nave, (nave_largura, nave_altura)) for nave in naves_loja]

    scroll_y = 0
    max_scroll_y = max(0, (len(naves_compradas) // 3) * (nave_altura + margem_vertical) - ALTURA + 200)

    while inventario_rodando:
        tela.fill(PRETO)
        tela.blit(moeda_img, (10, 10))
        desenha_texto(tela, f'{moedas}', fonte_moedas, BRANCO, 150, 50)

        desenha_texto(tela, "Inventário de Naves", fonte_game_over, BRANCO, LARGURA // 2 - fonte_game_over.size("Inventário de Naves")[0] // 2, 20)

        for i in naves_compradas:
            x = (i % 3) * (nave_largura + margem_horizontal) + (LARGURA // 2 - (3 * (nave_largura + margem_horizontal)) // 2)
            y = (i // 3) * (nave_altura + margem_vertical) + 150 - scroll_y
            nave_rect = pygame.Rect(x - 5, y - 5, nave_largura + 10, nave_altura + 60)
            pygame.draw.rect(tela, BRANCO, nave_rect)
            pygame.draw.rect(tela, CINZA_ESCURO, nave_rect, 2)
            tela.blit(naves_loja_redimensionadas[i], (x, y))

            selecionar_box = pygame.Rect(x, y + 160, 150, 30)
            pygame.draw.rect(tela, AZUL_ESCURO if i != nave_selecionada else VERDE, selecionar_box)
            desenha_texto(tela, "Selecionar", fonte_padrao, BRANCO, selecionar_box.centerx - fonte_padrao.size("Selecionar")[0] // 2, selecionar_box.y + 5)

            if selecionar_box.collidepoint(pygame.mouse.get_pos()):
                if pygame.mouse.get_pressed()[0]:
                    nave_selecionada = i
                    salvar_nave_selecionada(i)

        pygame.draw.rect(tela, VERMELHO, voltar_box)
        desenha_texto(tela, "VOLTAR", fonte_padrao, BRANCO, voltar_box.centerx - fonte_padrao.size("VOLTAR")[0] // 2, voltar_box.y + 10)
        pygame.draw.rect(tela, BRANCO, voltar_box, 2)

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                inventario_rodando = False
            if evento.type == pygame.MOUSEBUTTONDOWN:
                if voltar_box.collidepoint(evento.pos):
                    inventario_rodando = False

        # Adicionar rolagem vertical
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            scroll_y = max(scroll_y - 10, 0)
        if keys[pygame.K_DOWN]:
            scroll_y = min(scroll_y + 10, max_scroll_y)

        pygame.display.flip()
        clock.tick(30)

    return moedas

def jogo(nome_perfil, moedas):
    pos_x = LARGURA // 2
    pos_y = ALTURA - 100
    rodando = True
    tiros = []
    obstaculos = []

    nave_selecionada = carregar_nave_selecionada()
    nave_img = naves_loja[nave_selecionada]

    while rodando:
        tela.blit(background_jogo, (0, 0))

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                rodando = False
                return False, moedas
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_SPACE:
                    tiros.append([pos_x + 75, pos_y])  # Ajustar a posição do tiro
                if evento.key == pygame.K_o:
                    tiros.append([pos_x + 75, pos_y])  # Ajustar a posição do tiro

        teclas = pygame.key.get_pressed()
        if teclas[pygame.K_a]:
            pos_x -= velocidade
        if teclas[pygame.K_d]:
            pos_x += velocidade
        if teclas[pygame.K_w]:
            pos_y -= velocidade
        if teclas[pygame.K_s]:
            pos_y += velocidade

        if pos_x < 0:
            pos_x = 0
        if pos_x > LARGURA - 200:  # Ajustar a posição máxima da nave
            pos_x = LARGURA - 200
        if pos_y < 0:
            pos_y = 0
        if pos_y > ALTURA - 200:  # Ajustar a posição máxima da nave
            pos_y = ALTURA - 200

        if random.randint(1, 20) == 1:
            obstaculos.append([random.randint(0, LARGURA-100), -100])  # Ajustar a posição inicial dos asteroides

        for obstaculo in obstaculos:
            obstaculo[1] += velocidade
            if obstaculo[1] > ALTURA:
                obstaculos.remove(obstaculo)

        for obstaculo in obstaculos:
            if pos_x < obstaculo[0] + 100 and pos_x + 200 > obstaculo[0] and pos_y < obstaculo[1] + 100 and pos_y + 200 > obstaculo[1]:  # Ajustar a colisão
                rodando = False
                tela.fill(PRETO)
                game_over_text = "GAME OVER"
                game_over_surface = fonte_game_over.render(game_over_text, True, VERMELHO)
                game_over_rect = game_over_surface.get_rect(center=(LARGURA // 2, ALTURA // 2))
                tela.blit(game_over_surface, game_over_rect)
                pygame.display.flip()
                pygame.time.wait(3000)
                return True, moedas

        for tiro in tiros:
            for obstaculo in obstaculos:
                if tiro[0] < obstaculo[0] + 100 and tiro[0] + 5 > obstaculo[0] and tiro[1] < obstaculo[1] + 100 and tiro[1] + 10 > obstaculo[1]:  # Ajustar a colisão do tiro
                    tiros.remove(tiro)
                    obstaculos.remove(obstaculo)
                    moedas += 50
                    break

        for tiro in tiros:
            tiro[1] -= velocidade_tiro
            if tiro[1] < 0:
                tiros.remove(tiro)

        for tiro in tiros:
            pygame.draw.rect(tela, BRANCO, pygame.Rect(tiro[0], tiro[1], 5, 10))

        for obstaculo in obstaculos:
            tela.blit(asteroide_img, (obstaculo[0], obstaculo[1]))

        tela.blit(moeda_img, (10, 10))
        desenha_texto(tela, f'{moedas}', fonte_moedas, BRANCO, 150, 50)  # Ajustar a posição do texto das moedas

        tela.blit(nave_img, (pos_x, pos_y))

        nome_surface = fonte.render(nome_perfil, True, BRANCO)
        nome_rect = nome_surface.get_rect(center=(pos_x + 100, pos_y - 20))  # Ajustar a posição do nome
        tela.blit(nome_surface, nome_rect)

        pygame.display.flip()
        clock.tick(60)

    return moedas

criar_banco_de_dados()

moedas, nave_selecionada = carregar_dados()

while True:
    nome_perfil, abrir_loja, abrir_inventario = tela_inicial(moedas)
    if abrir_loja:
        moedas = tela_loja(moedas)
    elif abrir_inventario:
        moedas = tela_inventario(moedas)
    else:
        game_over, moedas = jogo(nome_perfil, moedas)
        if game_over:
            continue

    salvar_dados(moedas, nave_selecionada)

pygame.quit()